/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package libreria.cun;

/**
 *
 * @author salag504
 */
public class libro {
      private String titulo;
    private String autor;
    private String isbn;
    private double precio;

        // Constructor
    public libro(String titulo, String autor, String isbn, double precio) {
        this.titulo = titulo;
        this.autor = autor;
        this.isbn = isbn;
        this.precio = precio;
    }
    // ... resto de la clase .
}
