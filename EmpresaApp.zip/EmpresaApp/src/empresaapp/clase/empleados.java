/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package empresaapp.clase;

/**
 *
 * @author salag504
 */
public class empleados {
private String nombreCompleto; 
private String idEmpleado ;
private double salarioMensual; 
private String departamento;

    public empleados(String nombreCompleto, String idEmpleado, double salarioMensual, String departamento) {
        this.nombreCompleto = nombreCompleto;
        this.idEmpleado = idEmpleado;
        this.salarioMensual = 0;
        this.departamento = departamento;
    }
    
        
}
